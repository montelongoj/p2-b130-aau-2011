function GetXList(type, divid, id, amount) {
	$(divid).innerHTML = "Loading - Please wait!";
	if (window[type] == "") { window[type] = "0"; }
	if (window[type] != "1") {
		new Ajax.Updater(divid, 'ajax/' + type + '.php?id=' + id + '', {asynchronous:true});
		window[type] = "1";
		$(divid + 'Img').src = "http://nordic-t.org/pic/minus.gif";
	} else if (window[type] == "1") { 
		window[type] = "0";
		Element.update(divid, amount + ' objects');
		 $(divid + 'Img').src = "http://nordic-t.org/pic/plus.gif";
	}
}

function ExpandXCollapse(divid) {
	if (window[divid] == "") { window[divid] = "0"; }
	if (window[divid] != "1") {
		Effect.BlindDown(divid + '_column');
		$(divid + '_icon').src = "http://nordic-t.org/pic/minus.gif";
		window[divid] = "1";
	} else if (window[divid] == "1") {
		Effect.BlindUp(divid + '_column');
		$(divid + '_icon').src = "http://nordic-t.org/pic/plus.gif";
		window[divid] = "0";
	}
}

/***********************************************************************/
/**********************Basket mod 2008-08-10****************************/
/***********************************************************************/
function addProduct(prodid, amount) {
	sendData(prodid, amount);
}
function loadCart () {
	var myAjax = new Ajax.Updater('cart', 'cart.php', {onComplete: showResponse});
}
function sendData (prod, amount) {
	var url    = 'cart.php';
	var rand   = Math.random(9999);
	var pars   = 'product_id=' + prod + '&rand=' + rand + '&amount=' + amount;
	var myAjax = new Ajax.Request( url, {method: 'get', parameters: pars, onComplete: showResponse} );
}
function clearCart () {
	var url    = 'cart.php';
	var rand   = Math.random(9999);
	var pars   = 'clear=true&rand=' + rand;
	var myAjax = new Ajax.Request( url, {method: 'get', parameters: pars, onComplete: showResponse} );
}
function clearProduct (id) {
	var url    = 'cart.php';
	var rand   = Math.random(9999);
	var pars   = 'clearProduct=true&id=' + id + '&rand=' + rand;
	var myAjax = new Ajax.Request( url, {method: 'get', parameters: pars, onComplete: showResponse} );
}
function showResponse (originalRequest) {
	$('cart').innerHTML = originalRequest.responseText;
}
