startList = function() {
if (document.all&&document.getElementById) {
navRoot = document.getElementById("nav");
for (i=0; i<navRoot.childNodes.length; i++) {
node = navRoot.childNodes[i];
if (node.nodeName=="LI") {
node.onmouseover=function() {
this.className+=" over";
  }
  node.onmouseout=function() {
  this.className=this.className.replace(" over", "");
   }
   }
  }
 }
}
window.onload=startList;


function toggle(id,id2)
{
	el = document.getElementById(id);
	el.style.display = (el.style.display == 'none') ? 'block' : 'none';
	
	icon = document.getElementById(id2);
	image = (el.style.display == 'none') ? 'plus.gif' : 'minus.gif';
	
	icon.src = 'pic/' + image ;
}
